﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Bienvenido al programa de operaciones aritméticas.");

        Console.Write("Por favor, ingresa el primer número entero: ");
        int numero1 = Convert.ToInt32(Console.ReadLine());

        Console.Write("Por favor, ingresa el segundo número entero: ");
        int numero2 = Convert.ToInt32(Console.ReadLine());

        int suma = numero1 + numero2;
        int resta = numero1 - numero2;
        int multiplicacion = numero1 * numero2;
        double division = (double)numero1 / numero2;

        Console.WriteLine("La suma de los números es: " + suma);
        Console.WriteLine("La resta de los números es: " + resta);
        Console.WriteLine("La multiplicación de los números es: " + multiplicacion);
        Console.WriteLine("La división de los números es: " + division);

        if (numero2 != 0 && numero1 % numero2 == 0)
        {
            Console.WriteLine(numero2 + " es divisor de " + numero1);
        }
        else
        {
            Console.WriteLine(numero2 + " no es divisor de " + numero1);
        }
    }
}
